import type { Config } from './config.js';
/**
 * scansci-pdf CLI 适配器（Phase 0）。
 * 只做确定性包装：子进程调用 + JSON 解析 + 配置读写；不做任何判断。
 */
export interface RunResult {
    exitCode: number;
    stdout: string;
    stderr: string;
}
export declare function runCommand(exe: string, args: string[], opts?: {
    timeoutMs?: number;
    env?: NodeJS.ProcessEnv;
    input?: string;
}): Promise<RunResult>;
/**
 * 从混合输出里提取第一个可解析的 JSON 对象。
 * scansci 的 to_json 是 indent=2 的多行结构，rich 控制台还会混入其他行，
 * 所以按“{ 开头的行 → 花括号配平”提取。
 */
export declare function extractJson(stdout: string): Record<string, unknown> | null;
/** 通用 JSON 提取：对象或数组（library-list/search 输出 JSON 数组） */
export declare function extractJsonValue(stdout: string): unknown;
export declare function wrapScriptPath(): string;
/** OA 使用显式解释器或插件托管环境，不自动复用用户级 ScanSci 工具。 */
export declare function resolveScansciPython(config: Config): Promise<string | null>;
/** A 的下载只能走固定 OA wrapper，缺失时不回退综合下载器。 */
export declare function runScansci(exe: string, args: string[], config: Config, opts?: {
    timeoutMs?: number;
    useWrap?: boolean;
    env?: NodeJS.ProcessEnv;
    input?: string;
}): Promise<RunResult>;
export declare function probeScansci(exe: string): Promise<boolean>;
export declare function probeOaProvider(config: Config): Promise<boolean>;
export declare function doctorScansci(exe: string): Promise<string>;
export declare function installScansci(python: string): Promise<RunResult>;
export interface LegalConfigState {
    path: string;
    legalOnly: boolean;
    school: string;
    outputDir: string;
    existed: boolean;
    changed: boolean;
}
export declare function readScansciConfig(config: Config): Promise<Record<string, unknown>>;
export declare function ensureScansciConfig(config: Config): Promise<LegalConfigState>;
export interface PaperInfo {
    doi: string;
    title: string;
    authors: string[];
    journal: string;
    year: number | null;
    source: string;
    url: string;
    pdf_path: string;
}
export interface FetchOutcome {
    status: string;
    quality: string;
    reason?: string;
    next_action?: {
        kind: string;
        message: string;
        command?: string;
    } | null;
    paper?: PaperInfo;
    raw?: Record<string, unknown>;
}
export declare function fetchPaper(exe: string, identifier: string, outputDir: string, config: Config): Promise<FetchOutcome>;
export declare function loginScansci(exe: string, loginType: string, url?: string): Promise<RunResult>;
export declare function setSchoolScansci(exe: string, school: string): Promise<RunResult>;
export declare function defaultDownloadDir(): Promise<string>;
export declare function ensureBundledEngine(config: Config): Promise<{
    ok: boolean;
    python: string;
    detail: string;
}>;
/** 解析内置引擎 Python：显式开发覆盖 → 数据目录虚拟环境。 */
export declare function resolveEnginePython(config: Config): Promise<string | null>;
/** 运行引擎 CLI：python -m scientific_reading --data-root <dataRoot> ... */
export declare function runEngine(config: Config, args: string[], opts?: {
    timeoutMs?: number;
    env?: NodeJS.ProcessEnv;
    input?: string;
}): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
/** 运行引擎并解析 JSON；input 通过 UTF-8 stdin 传入，避免把元数据拼进命令行。 */
export declare function engineJson(config: Config, args: string[], input?: unknown, env?: NodeJS.ProcessEnv): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
/** 启动不等待结果的引擎子进程。子进程只继承宿主环境，不把环境值写入日志。 */
export declare function engineStartDetached(config: Config, args: string[], input?: unknown): Promise<{
    started: boolean;
    detail?: string;
}>;
/** 持久派生编排：引擎负责记录 pending/failed 状态，插件只提交一次。 */
export declare function engineDerivedEnqueue(config: Config, paperId: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
/** Abstract agent gate：只提交 agent 提供的翻译，不自动生成或伪造翻译。 */
export declare function engineAbstractReadSubmit(config: Config, jobId: string, abstractTranslation: unknown): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
/** 两阶段入库：先执行本地事务，派生阶段由调用方提交一次持久 derived-enqueue。 */
export declare function engineLibraryIngest(config: Config, input: unknown): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
/** library-list-v2：分页、查询、文件夹、标签和状态筛选。 */
export declare function engineLibraryList(config: Config, options?: {
    page?: number;
    pageSize?: number;
    query?: string;
    folder?: string;
    tags?: string[];
    status?: string;
}): Promise<{
    ok: boolean;
    json: unknown;
    stderr: string;
}>;
/** library-item-v2：按主库 paper_id 读取摘要与派生状态。 */
export declare function engineLibraryItem(config: Config, paperId: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineFolderManage(config: Config, args: string[]): Promise<{
    ok: boolean;
    json: unknown;
    stderr: string;
}>;
export declare function engineClassification(config: Config, command: 'classification-apply' | 'classification-undo', input?: unknown, operationId?: string): Promise<{
    ok: boolean;
    json: unknown;
    stderr: string;
}>;
/** library-ensure：写入本地文献库条目（查重+读回） */
export declare function engineJobStatus(config: Config, jobId: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineStartFullRead(config: Config, paperId: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineContinueFullRead(config: Config, jobId: string, suppliedInput: Record<string, unknown>): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineAttachAndResumeFullReadPdf(config: Config, paperId: string, jobId: string, pdfPath: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineAttachLibraryPdf(config: Config, paperId: string, pdfPath: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineExportAssets(config: Config, paperId: string): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineResolveArtifact(config: Config, paperId: string, kind: 'pdf' | 'reader' | 'exports'): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function engineReviewOpenState(config: Config, parentSessionId: string, paperId: string): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
export declare function engineReviewBind(config: Config, parentSessionId: string, paperId: string, reviewSessionId: string): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
export declare function engineReviewContext(config: Config, reviewSessionId: string): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
export declare function engineReviewConfirm(config: Config, reviewSessionId: string, conclusions: unknown[]): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
export declare function engineXlsxRefresh(config: Config): Promise<{
    ok: boolean;
    exitCode: number;
    stdout: string;
    stderr: string;
    json: Record<string, unknown> | null;
}>;
/** library-ensure --check：只读查重 */
