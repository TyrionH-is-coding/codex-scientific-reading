import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from 'cordis';
import type { Config } from './config.js';
interface ParentAgentLike {
    id: string;
    session: {
        header: {
            id: string;
            agentPreset?: string;
        };
    };
}
interface ReviewStartSpec {
    provider: 'fork';
    label: string;
    request: {
        prompt: Array<{
            type: 'text';
            text: string;
        }>;
        parent: ParentAgentLike;
    };
    signal: AbortSignal;
}
interface ReviewBinding {
    status: string;
    parent_session_id: string;
    paper_id: string;
    review_session_id: string;
}
interface ReviewOpenState {
    status: string;
    parent_session_id: string;
    paper_id: string;
    title: string;
    review_session_id?: string;
}
export interface ReviewSessionDependencies {
    readState(parentSessionId: string, paperId: string): Promise<ReviewOpenState>;
    getParent(parentSessionId: string): ParentAgentLike | undefined;
    startContinuable(spec: ReviewStartSpec): Promise<{
        childId: string;
        messageId: string;
    }>;
    bind(parentSessionId: string, paperId: string, reviewSessionId: string): Promise<ReviewBinding>;
}
export interface ReviewSessionOpenResult {
    status: 'created' | 'reused';
    parent_session_id: string;
    paper_id: string;
    review_session_id: string;
    mode: 'continuable';
}
export declare function createReviewSessionOpener(deps: ReviewSessionDependencies, presetId: string): {
    open(parentSessionId: string, paperId: string, signal?: AbortSignal): Promise<ReviewSessionOpenResult>;
};
export declare function sendJson(res: ServerResponse, status: number, value: unknown): void;
export declare function sameOrigin(req: IncomingMessage): boolean;
export declare function readJson(req: IncomingMessage, limit?: number): Promise<Record<string, unknown>>;
export declare function registerReviewSessionRoutes(ctx: Context, config: Pick<Config, 'presetId'>, suppliedOpener?: ReturnType<typeof createReviewSessionOpener>): void;
export {};
