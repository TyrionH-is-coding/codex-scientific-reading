import type { Config } from './config.js';
export interface InstitutionSchool {
    name: string;
    province: string;
    type: string;
}
export declare const institutionDependencies: {
    schools(config: Config): Promise<InstitutionSchool[]>;
    status(config: Config): Promise<Record<string, unknown>>;
    select(config: Config, school: string): Promise<Record<string, unknown>>;
    login(config: Config): Promise<Record<string, unknown>>;
};
