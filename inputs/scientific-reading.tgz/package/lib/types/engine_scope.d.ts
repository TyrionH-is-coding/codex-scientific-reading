export interface EngineScope {
    instanceId: string;
    scopeSessionId: string;
    scopeFolderId: string;
    scopePaperId?: string;
    scopePaperRevision?: number;
}
/** 仅供可信宿主桥使用；不得把 scope 作为模型可填写的工具参数。 */
export declare function withEngineScope<T>(scope: EngineScope, action: () => T): T;
export declare function engineScopeEnvironment(): NodeJS.ProcessEnv;
/** 仅用于可信宿主解析真实会话绑定；业务操作仍必须继承当前作用域。 */
export declare function withoutEngineScope<T>(action: () => T): T;
