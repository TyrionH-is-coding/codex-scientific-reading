import type { Context } from 'cordis';
import type { Config } from './config.js';
export declare const BATCH_ACTIONS: Set<string>;
export declare function submitBatch(config: Config, request: Record<string, unknown>): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function listNavigation(config: Config, options: {
    page: number;
    pageSize: number;
    query?: string;
    folder?: string;
    tags: string[];
    status?: string;
    recentDays?: number;
}): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function resolveNavigationArtifact(config: Config, paperId: string, kind: 'pdf'): Promise<{
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
}>;
export declare function registerLibraryTools(ctx: Context, config: Config): void;
