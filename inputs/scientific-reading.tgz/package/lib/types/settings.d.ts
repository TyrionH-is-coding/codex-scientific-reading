/**
 * 设置注册（T2.4）：设置页插件配置卡片。
 *
 * 机制：installSettingsSection 注册 `scientific-reading` namespace（Config schema，
 * composition entry 作 base 层）。设置文档/页面变更时，onChange 把最新 resolved
 * 值原地 Object.assign 回初始 config 对象——tools/routes 的闭包持有同一引用，
 * 无需改任何模块签名即可读到新配置（零侵入联动）。
 */
import type { Context } from 'cordis';
import { type Config as PluginConfig } from './config.js';
/** 设置 namespace：kebab-case，与插件短名一致。 */
export declare const SETTINGS_NS = "scientific-reading";
/**
 * 注册设置 section 并把配置变更联动到 `config` 对象。
 * @param ctx - 插件上下文（apply 的 ctx）。
 * @param config - composition entry config（apply 的 config；会被原地同步）。
 */
export declare function registerSettings(ctx: Context, config: PluginConfig): void;
