import type { Config } from './config.js';
type FetchResult = {
    status: string;
    pdfPath?: string;
};
type Child = {
    paperId: string;
    status: string;
    phase?: string;
};
type DownloadJob = Record<string, unknown>;
export type DownloadDeps = {
    loadPaper(id: string): Promise<Record<string, unknown> | undefined>;
    hasPdf(id: string): Promise<boolean>;
    directFetch(id: string, paper: Record<string, unknown>): Promise<FetchResult>;
    attachPdf(id: string, path: string): Promise<{
        status: string;
    }>;
};
export declare function runDownloadBatch(selection: string[], deps: DownloadDeps): Promise<{
    status: string;
    children: Child[];
    summary: Record<string, number>;
    challengePaperIds: string[];
}>;
export declare function submitDownloadBatch(config: Config, selection: string[]): Promise<{
    parent_job_id: string;
    status: string;
}>;
export declare function readDownloadJob(config: Config, jobId: string): Promise<DownloadJob | null>;
export {};
