import type { Context } from 'cordis';
declare module 'cordis' {
    interface Context {
        webServer: {
            register(route: {
                kind: 'exact' | 'prefix';
                path: string;
                handler: (req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse) => void | Promise<void>;
            }): () => void;
        };
    }
}
import type { Config } from './config.js';
type EvidenceEngineResult = {
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
};
export interface EvidenceRouteDependencies {
    resolveConclusion(config: Config, conclusionId: string): Promise<EvidenceEngineResult>;
}
/**
 * 文献页 API 路由（只读数据 + 动作触发）。动作端点复用插件同一套引擎适配器。
 * 安全：paper_id / job_id 白名单校验；只读 dataRoot 内路径。
 */
export declare function registerRoutes(ctx: Context, config: Config, evidenceDependencies?: EvidenceRouteDependencies): void;
export {};
