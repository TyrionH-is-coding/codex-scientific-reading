import type { Context } from 'cordis';
import type { Config } from './config.js';
type EngineResult = {
    ok: boolean;
    json: Record<string, unknown> | null;
    stderr: string;
};
export interface ReviewToolDependencies {
    context(config: Config, reviewSessionId: string): Promise<EngineResult>;
    confirm(config: Config, reviewSessionId: string, conclusions: unknown[]): Promise<EngineResult>;
    refreshXlsx(config: Config): Promise<EngineResult>;
    locate(config: Config, input: EvidenceLocateInput): Promise<EngineResult>;
    prepareCandidate(config: Config, input: CandidateRebuildInput): Promise<EngineResult>;
}
type EvidenceLocateInput = {
    paper_id: string;
    block_id: string;
    quote: string;
    page?: number;
};
type CandidateRebuildInput = {
    paper_id: string;
    target_root: string;
};
export declare function registerReviewTools(ctx: Context, config: Config, dependencies?: ReviewToolDependencies): void;
export {};
