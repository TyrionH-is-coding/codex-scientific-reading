import type { Context } from 'cordis';
import { type Config } from './config.js';
type Engine = (args: string[], input?: unknown) => Promise<any>;
type Rpc = (method: string, payload: Record<string, unknown>) => Promise<any>;
export declare const PAPER_TOOLS: Set<string>;
export declare function configEngine(config: Config): Engine;
export declare function createNativeRpc(ctx: Context): (method: string, payload: Record<string, any>, requestId?: `${string}-${string}-${string}-${string}-${string}`) => Promise<any>;
export declare function nativeRpc(url: string, method: string, payload: Record<string, unknown>): Promise<any>;
export declare function readPaperJobInput(dataRoot: string, engine: Engine, args: any): Promise<{
    job_id: any;
    field: any;
    offset: any;
    total: number;
    text: string;
    nextOffset: any;
}>;
/** Public conversation text and tool evidence, excluding internal reasoning and hidden prompts. */
export declare function conversationEvents(entries: any[]): {
    seq: any;
    time: any;
    role: any;
    content: any;
    evidence_status: string;
}[];
/** Pin pages by beforeSeq and SHA so a long read cannot combine different revisions. */
export declare function readSelectedChats(engine: Engine, rpc: Rpc, request: any): Promise<{
    question: string;
    selectedPaperIds: any[];
    chats: any[];
    instructions: string;
}>;
export declare function readLegacyChat(engine: Engine, rpc: Rpc, request: any): Promise<any>;
export declare function discussFigure(engine: Engine, rpc: Rpc, request: any, origin?: string): Promise<{
    session_id: any;
    context: any;
    chat_url: string;
}>;
export declare function registerPaperSessionRoutes(ctx: Context, config: Config): void;
export declare function registerPaperTools(ctx: Context, config: Config): void;
export {};
