export declare function isPaperId(value: string): boolean;
/** 严格解析 paper 路由，拒绝编码错误、路径穿越和多余层级。 */
export declare function parsePaperRoute(url: string, base: string): string[] | null;
export declare function paperMetadataPath(dataRoot: string, paperId: string): string;
