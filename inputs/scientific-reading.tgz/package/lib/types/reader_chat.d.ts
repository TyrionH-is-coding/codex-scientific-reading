import type { Context } from 'cordis';
import type { Config } from './config.js';
export declare function readerPage(html: string, offline: boolean): string;
export declare function readerDisplaySha(html: string): string;
export declare function registerReaderChat(ctx: Context, config: Config): void;
