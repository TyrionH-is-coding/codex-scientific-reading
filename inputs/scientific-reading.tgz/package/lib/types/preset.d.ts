import type { Context } from 'cordis';
import type { Config as PluginConfig } from './config.js';
export declare const DEFAULT_PRESET_ID = "scientific-reading";
export declare const PRESET_DISPLAY_NAME = "\u6587\u732E\u6A21\u5F0F";
export interface AgentPresetsLike {
    standingKeyFor(id: string): Promise<unknown>;
    standing?: Map<string, Promise<StandingScopeRecord>>;
}
export interface StandingScopeRecord {
    key: unknown;
    scope: {
        ctx: object;
    };
}
export interface PresetHostContext extends Context {
    agentPresets?: AgentPresetsLike;
}
/**
 * 与 `@deepseek-ai/dsh-paths` 一致：非空 `$DSH_HOME`，否则 `~/.dsh`。
 */
export declare function resolveDshHome(env?: Record<string, string | undefined>): string;
export declare function packagedPresetDir(): string;
export declare function resolvePresetId(config: Pick<PluginConfig, 'presetId'>): string;
/**
 * 把打包的 `preset/scientific-reading/` 安装到 `$DSH_HOME/.agent-presets/<id>/`。
 * 已存在的目录保留用户配置；仅迁移 DSH 0.1.5 的 persona 字段名，并保存旧文件。
 */
export declare function installPreset(ctx: Context, presetId: string): Promise<boolean>;
export declare function readPackagedPresetComposition(): Promise<string>;
/** 从 AgentPresets 已创建的 standing mount 读取宿主单例的 scope tag。 */
export declare function standingScopeTag(ctx: PresetHostContext, presetId: string, key: unknown): Promise<symbol>;
/** 把 sr_* 工具注册到文献模式 standing key 上；其他模式看不到这些工具。 */
export declare function mountPresetCapabilities(ctx: PresetHostContext, key: unknown, scopeTag: symbol, config: PluginConfig): Promise<void>;
export declare function mountLiteratureTools(ctx: PresetHostContext, config: PluginConfig): Promise<boolean>;
