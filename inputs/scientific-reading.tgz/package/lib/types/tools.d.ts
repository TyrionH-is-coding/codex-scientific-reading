import type { Context } from 'cordis';
import type { Config } from './config.js';
/** Phase 0 工具集。所有注册挂 ctx.effect（热重载/卸载自动注销）。 */
export declare function registerTools(ctx: Context, config: Config): void;
