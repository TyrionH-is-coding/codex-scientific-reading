/** DSH 单仓库文献工作流插件；所有资源注册挂 ctx.effect 自动清理。 */
import type { Context } from 'cordis';
import { Config, type Config as PluginConfig } from './config.js';
export declare const name = "@dsh-external/dsh-scientific-reading";
export declare const inject: string[];
export { Config };
export { withEngineScope, withoutEngineScope, type EngineScope } from './engine_scope.js';
export { engineJson, engineStartFullRead, engineContinueFullRead, engineAttachAndResumeFullReadPdf } from './cli.js';
export { createNativeRpc, readSelectedChats, readLegacyChat, PAPER_TOOLS } from './paper_sessions.js';
export { DEFAULT_PRESET_ID, PRESET_DISPLAY_NAME, installPreset, mountLiteratureTools, resolveDshHome, } from './preset.js';
export declare function apply(ctx: Context, config: PluginConfig): Promise<void>;
