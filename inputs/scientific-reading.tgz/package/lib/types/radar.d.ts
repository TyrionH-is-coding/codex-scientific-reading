import type { Context } from 'cordis';
import type { Config } from './config.js';
export declare function registerRadarRoutes(ctx: Context, config: Config): void;
export declare function registerRadarTools(ctx: Context, config: Config): void;
