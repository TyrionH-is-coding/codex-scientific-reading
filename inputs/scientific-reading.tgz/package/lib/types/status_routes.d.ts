import type { Context } from 'cordis';
import type { Config } from './config.js';
export declare function registerStatusRoutes(ctx: Context, config: Config): void;
