import type { Context } from 'cordis';
import { ReasoningEffortId } from '@deepseek-ai/dsh-llm';
import type { Config } from './config.js';
export declare const MODEL_STEPS: readonly ["radar_direction", "radar_assessment", "abstract_translation", "full_translation", "full_review", "classification", "research_fields", "paper_chat", "figure_chat", "multi_paper_summary", "reader_chat"];
type Choice = {
    provider: string;
    model: string;
    reasoningEffort: string;
};
export declare function modelCatalog(ctx: Context): Promise<{
    models: ({
        provider: string;
        id: string;
        name: string;
        providerName: string;
        inputModalities: readonly import("@deepseek-ai/dsh-llm").ModelModality[] | undefined;
        efforts: string[];
    } | {
        provider: string;
        id: string;
        name: string;
        providerName: string;
        efforts: never[];
        inputModalities?: undefined;
    })[];
    unavailableProviders: string[];
}>;
export declare function resolveChoice(ctx: Context, choice: Choice, signal?: AbortSignal): Promise<{
    reasoningEffort?: ReasoningEffortId | undefined;
    provider: string;
    model: string;
}>;
export declare function stepChoice(ctx: Context, config: Config, step: string, signal?: AbortSignal): Promise<{
    reasoningEffort?: ReasoningEffortId | undefined;
    provider: string;
    model: string;
}>;
/** 从真实工具结果恢复本轮步骤；论文文本里的指令或步骤名不参与路由。 */
export declare function stepFromEvents(events: readonly any[], fallback?: string): string;
export declare function registerModelPolicy(ctx: Context, config: Config): void;
export declare function registerModelPolicyTools(ctx: Context, config: Config): void;
export {};
